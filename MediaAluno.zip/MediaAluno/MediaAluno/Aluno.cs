﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace MediaAluno
{
    public class Aluno(string Nome, string RM, DateOnly DataNascimento, int Idade)
    {
        static int GetIdade(DateTime DataNascimento)
        {
            DateTime Hoje = DateTime.Now;
            int Idade = Hoje.Year - DataNascimento.Year;

            return Idade;
        }
        public void Envelhecer()
        {
            Idade++;
        }
    }
}
